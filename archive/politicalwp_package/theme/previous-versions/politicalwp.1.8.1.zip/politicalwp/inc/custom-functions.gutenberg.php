<?php
/**
 * Load Gutenberg stylesheet.
 */
function politicalwp_add_gutenberg_assets() {
	// Load the theme styles within Gutenberg.
	wp_enqueue_style( 'politicalwp-gutenberg-style', get_theme_file_uri( '/css/gutenberg-editor-style.css' ), false );
	wp_enqueue_style( 'wp-block-library' ); 
    wp_enqueue_style( 
        'politicalwp-gutenberg-fonts', 
        '//fonts.googleapis.com/css?family=Arvo%3Aregular%2Citalic%2C700%2C700italic%2Clatin%7COpen+Sans%3A300%2C300italic%2Cregular%2Citalic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic%2Cvietnamese%2Cgreek%2Clatin-ext%2Cgreek-ext%2Ccyrillic-ext%2Clatin%2Ccyrillic' 
    ); 
}
add_action( 'enqueue_block_editor_assets', 'politicalwp_add_gutenberg_assets' );

/**
 * Gutenberg body class.
 */
function politicalwp_add_gutenberg_body_class( $body_classes ) {
	if ( is_singular() && false !== strpos( get_queried_object()->post_content, '<!-- wp:' ) ) {
		$body_classes[] = 'gutenberg';
	}
	return $body_classes;
}
add_filter( 'body_class', 'politicalwp_add_gutenberg_body_class' );
?>