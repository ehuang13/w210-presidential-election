<?php
/**
 * The template for displaying a standard search form.
 *
 * @package Listify
 */
?>

<form role="search" method="get" class="search-form" action="<?php echo esc_url(home_url('/')); ?>">
	<label>
		<span class="screen-reader-text"><?php esc_attr_e( 'Search for:', 'politicalwp' ); ?></span>
		<input type="search" class="search-field" placeholder="<?php esc_attr_e( 'Search', 'politicalwp' ); ?>" value=""
		name="s" title="<?php esc_attr_e( 'Search for:', 'politicalwp' ); ?>" />
	</label>
	<input class="search-submit" value="&#xe090;" type="submit">
</form>