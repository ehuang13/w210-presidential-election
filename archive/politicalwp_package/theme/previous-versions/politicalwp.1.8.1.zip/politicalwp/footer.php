<?php
/**
 * The template for displaying the footer.
 *
*/
?>

    <!-- FOOTER -->
    <footer>
        <!-- FOOTER TOP -->
        <div class="row footer-top">
            <div class="container">
            <?php
                if ( class_exists( 'ReduxFrameworkPlugin' ) ) {
                    //FOOTER WIDGETS ROW 1
                    echo wp_kses_post(politicalwp_footer_row1());
                    //FOOTER WIDGETS ROW 2
                    echo wp_kses_post(politicalwp_footer_row2());
                    //FOOTER WIDGETS ROW 3
                    echo wp_kses_post(politicalwp_footer_row3());
                }
            ?>
            </div>
        </div>

        <!-- FOOTER BOTTOM -->
        <div class="row footer">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <p class="copyright"><?php echo wp_kses_post(politicalwp_redux('mt_footer_text')); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</div>

<?php if ( ! class_exists( 'ReduxFrameworkPlugin' ) ) { ?>
    <!-- BACK TO TOP BUTTON -->
    <a class="back-to-top themeslr-is-visible themeslr-fade-out" href="#0">
        <span></span>
    </a>
<?php }else{ ?>
    <?php if (politicalwp_redux('mt_backtotop_status') == true) { ?>
        <?php 
        if (politicalwp_redux('mt_backtotop_border_status') == 0) {
            $border_status = 'has-no-border';
        }else{
            $border_status = 'has-border';
        } ?>
        <!-- BACK TO TOP BUTTON -->
        <a class="back-to-top themeslr-is-visible themeslr-fade-out <?php echo esc_attr($border_status); ?>" href="#0">
            <span></span>
        </a>
    <?php } ?>
<?php } ?>


<?php wp_footer(); ?>
</body>
</html>