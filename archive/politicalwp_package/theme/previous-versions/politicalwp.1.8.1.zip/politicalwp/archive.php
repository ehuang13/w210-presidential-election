<?php
/**
 * The template for displaying archive pages.
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 */

get_header(); 



$class = "";
if ( politicalwp_redux('mt_blog_layout') == 'mt_blog_fullwidth' ) {
    $class = "col-md-12";
}elseif ( politicalwp_redux('mt_blog_layout') == 'mt_blog_right_sidebar' or politicalwp_redux('mt_blog_layout') == 'mt_blog_left_sidebar') {
    $class = "col-md-9";
}
$sidebar = politicalwp_redux('mt_blog_layout_sidebar');
?>


<!-- HEADER TITLE BREADCRUBS SECTION -->
<?php echo politicalwp_header_title_breadcrumbs(); ?>


<!-- Page content -->
<div class="high-padding">
    <!-- Blog content -->
    <div class="container blog-posts">
        <div class="row">
            <div class="col-md-12 main-content">
            <?php if ( have_posts() ) : ?>
                <div class="row">

                    <?php if ( politicalwp_redux('mt_blog_layout') == 'mt_blog_left_sidebar' && is_active_sidebar( politicalwp_redux('mt_blog_layout_sidebar') )) { ?>
                        <div class="col-md-3 sidebar-content">
                            <?php dynamic_sidebar( politicalwp_redux('mt_blog_layout_sidebar') ); ?>
                        </div>
                    <?php } ?>

                    <div class='<?php echo esc_attr($class); ?>'>
                        <div class="row">
                            <?php /* Start the Loop */ ?>
                            <?php while ( have_posts() ) : the_post(); ?>
                                    <?php get_template_part( 'content', 'post' ); ?>
                            <?php endwhile; ?>
                        </div>
                    </div>

                    <?php if ( politicalwp_redux('mt_blog_layout') == 'mt_blog_right_sidebar' && is_active_sidebar( politicalwp_redux('mt_blog_layout_sidebar') )) { ?>
                        <div class="col-md-3 sidebar-content">
                            <?php dynamic_sidebar( politicalwp_redux('mt_blog_layout_sidebar') ); ?>
                        </div>
                    <?php } ?>

                    <div class="clearfix"></div>

                    <div class="theme-pagination-holder col-md-12">             
                        <div class="theme-pagination pagination">             
                            <?php politicalwp_pagination(); ?>
                        </div>
                    </div>
                </div>
            <?php else : ?>
                <?php get_template_part( 'content', 'none' ); ?>
            <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php get_footer(); ?>